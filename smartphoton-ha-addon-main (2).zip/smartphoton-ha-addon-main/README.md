﻿# Smartphoton-HA Add-on  (english)

This add-on manages your hybrid inverter on a Voltronic base.
This add-on also manages your Pylontech batteries.

Communication with the inverter and/or batteries is either :

- USB ↔ RS232
- Via a TCP/IP gateway ↔ RS232 type Elfin [EE10](http://www.hi-flying.com/elfin-ee10-elfin-ee11) or [EW10](http://www.hi-flying.com/elfin-ew10-elfin-ew11)(a)

The add-on engine is written in Nodered V3
This Add-on is a continuation of smartphoton V5.2
Please consult this [forum](https://domosimple.eu/forum/) or this [site](http://smartphoton.fr/) for more information. Currently the French language is used.
We plan to extend the add-on's capabilities to other inverters.
For example: EASUN, Growatt, SofarSolar, etc.

*The smartphoton team is made up of : Jean-luc / Alexis / Romain / Khamel / Samuel* 


# Smartphoton-HA Add-on (français)

Cet add-on sert à gérer votre onduleur hybride sur une base Voltronic.
Cet add-on gère aussi votre parc de batteries Pylontech

Les communication avec l’onduleur et/ou les batteries se font soit :

- Par un port USB ↔ RS232
- Par une passerelle TCP/IP ↔ RS232 de type Elfin [EE10](http://www.hi-flying.com/elfin-ee10-elfin-ee11) ou [EW10](http://www.hi-flying.com/elfin-ew10-elfin-ew11)(a)

Le moteur de l’add-on est écrit en Nodered V3
Cet Add-on est la suite de smartphoton V5.2
Veuillez consulter ce [forum](https://domosimple.eu/forum/) ou ce [site](http://smartphoton.fr/) pour plus d’informations. Actuellement la langue française est utilisée.
Nous prévoyons d’étendre les capacités de l’add-on vers d’autres onduleurs.
Par exemple : EASUN, Growatt, SofarSolar, etc.

*L’équipe smartphoton est composée par : Jean-luc / Alexis / Romain / Khamel / Samuel* 


